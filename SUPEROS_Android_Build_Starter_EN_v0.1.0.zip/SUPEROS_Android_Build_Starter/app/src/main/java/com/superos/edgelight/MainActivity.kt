package com.superos.edgelight

import android.app.Activity
import android.os.Bundle
import android.graphics.Point
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.ViewGroup

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val metrics = resources.displayMetrics
        val realDisplaySize = Point()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager)
            .defaultDisplay.getRealSize(realDisplaySize)
        val widthPx = realDisplaySize.x
        val heightPx = realDisplaySize.y
        val density = metrics.density
        val densityDpi = metrics.densityDpi

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(8, 8, 14))
        }

        fun addLine(value: String, size: Float, color: Int, bold: Boolean = false) {
            root.addView(TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, 10, 0, 10)
            }, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }

        addLine("SUPEROS EDGE LIGHT", 25f, Color.rgb(255, 70, 85), true)
        addLine("DEVICE DISPLAY DETECTED", 14f, Color.LTGRAY, true)
        addLine("Screen: ${widthPx} × ${heightPx} px", 20f, Color.WHITE, true)
        addLine("Density: ${densityDpi} dpi", 16f, Color.rgb(80, 190, 255))
        addLine("Scale: ${"%.2f".format(density)}", 16f, Color.rgb(80, 190, 255))
        addLine("These values are read from Android at runtime.", 13f, Color.LTGRAY)
        addLine("This is the first build-system test version (0.1.0).", 12f, Color.GRAY)
        setContentView(root)
    }
}
