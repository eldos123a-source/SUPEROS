# SUPEROS EDGE LIGHT — Android APK Build Starter

This is the **0.1.0 starter project**. The app reads the device's current physical display pixel dimensions from Android at runtime. One universal APK can adapt to different Android phones; a separate APK for every phone model is not required.

## Build the APK with GitHub Actions

1. Open your `SUPEROS` repository on GitHub.
2. Choose **Add file → Upload files**.
3. Upload the contents of this ZIP archive. Keep the `.github` folder and its `workflows` subfolder.
4. Commit the uploaded files to the `main` branch.
5. Open the repository's **Actions** tab.
6. Select **Build SUPEROS APK**.
7. Press **Run workflow**. If GitHub asks you to enable Actions, enable it.
8. Wait for the workflow to finish successfully.
9. Open the completed workflow run. Under **Artifacts**, download `SUPEROS-EDGE-LIGHT-debug`.
10. Extract the downloaded artifact ZIP. Install `app-debug.apk` on your Android phone.

## What this starter version does

- Builds one universal Android debug APK.
- Reads the main display's current pixel dimensions from Android using `getRealSize`.
- Displays the screen dimensions, density, and scale.

## Not included yet

- This is a device-detection and build-pipeline test, not the complete EDGE LIGHT effects app.
- The website's **DOWNLOAD APK** button is not connected to GitHub Actions yet.
- Release signing, production distribution, and full foldable-display state handling will be added in later stages.

## Android permissions and safety

The app does not bypass Android permissions. It only reads display metrics available to a normal Android application.
